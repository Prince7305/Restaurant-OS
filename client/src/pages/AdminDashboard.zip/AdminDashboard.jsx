import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import MenuManagement from '../components/MenuManagement';
import TableManagement from '../components/TableManagement';

function AdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [dashboardData, setDashboardData] = useState({
    menuItems: 0,
    tables: 0,
    occupiedTables: 0,
    customers: 0,
    activeOrders: 0,
  });

  const token = localStorage.getItem('token');
  const user = JSON.parse(localStorage.getItem('user') || 'null');

  // Guard: no valid session, bounce straight to login instead of
  // showing a broken dashboard with no data.
  useEffect(() => {
    if (!token || !user) {
      navigate('/admin/login');
    }
  }, [token, user, navigate]);

  // Load dashboard stats when user loads
  useEffect(() => {
    if (!token || !user?.restaurantId) return;

    const fetchDashboardData = async () => {
      try {
        const headers = {
          Authorization: `Bearer ${token}`,
        };

        const [menuRes, tablesRes, customersRes, ordersRes] =
          await Promise.all([
            axios.get(
              `http://localhost:5000/api/menu/restaurant/${user.restaurantId}`,
              { headers }
            ),
            axios.get(
              `http://localhost:5000/api/tables/restaurant/${user.restaurantId}`,
              { headers }
            ),
            axios.get(
              `http://localhost:5000/api/customers/restaurant/${user.restaurantId}`,
              { headers }
            ),
            axios.get(
              `http://localhost:5000/api/orders/restaurant/${user.restaurantId}`,
              { headers }
            ),
          ]);

        const tables = tablesRes.data;
        const orders = ordersRes.data;

        setDashboardData({
          menuItems: menuRes.data.length,
          tables: tables.length,
          occupiedTables: tables.filter(
            (table) => table.status === 'occupied'
          ).length,
          customers: customersRes.data.length,
          activeOrders: orders.filter(
            (order) =>
              order.status === 'pending' ||
              order.status === 'preparing' ||
              order.status === 'ready'
          ).length,
        });
      } catch (error) {
        console.error('Failed to load dashboard data:', error);
      }
    };

    fetchDashboardData();
  }, [token, user?.restaurantId]);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/admin/login');
  };

  if (!user) return null; // brief flash before the redirect above kicks in

  return (
    <div className="min-h-screen bg-paper">
      <header className="bg-charcoal text-paper px-6 py-5 flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl">RestaurantOS</h1>
          <p className="font-body text-xs text-paper/40">{user.name}</p>
        </div>
        <div className="flex items-center gap-4">
          <Link to="/admin/kitchen" className="font-body text-sm text-paper/60">
            Kitchen
          </Link>
          <Link to="/admin/waiter" className="font-body text-sm text-paper/60">
            Waiter
          </Link>
          <button onClick={handleLogout} className="font-body text-sm text-paper/60">
            Sign out
          </button>
        </div>
      </header>

      {/* Tab switcher */}
      <div className="px-6 pt-5 flex gap-2 border-b border-line">
        {['overview', 'menu', 'tables'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`font-body text-sm capitalize px-4 py-2.5 -mb-px border-b-2 ${activeTab === tab
              ? 'border-paprika text-ink font-medium'
              : 'border-transparent text-ink/40'
              }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <main className="p-6 max-w-5xl">
        {activeTab === 'overview' && (
          <section>
            <div className="mb-8">
              <p className="font-body text-sm text-paprika mb-2">
                Restaurant operations
              </p>

              <h2 className="font-display text-4xl text-ink">
                Good evening, {user.name}
              </h2>

              <p className="font-body text-sm text-ink/50 mt-2">
                Here's what's happening in your restaurant.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="border border-line bg-white rounded-xl p-5">
                <p className="font-body text-xs text-ink/40 uppercase tracking-wider">
                  Active orders
                </p>
                <p className="font-display text-3xl text-ink mt-3">
                  {dashboardData.activeOrders}
                </p>
              </div>

              <div className="border border-line bg-white rounded-xl p-5">
                <p className="font-body text-xs text-ink/40 uppercase tracking-wider">
                  Tables
                </p>
                <p className="font-display text-3xl text-ink mt-3">
                  {dashboardData.occupiedTables}
                  <span className="font-body text-sm text-ink/40 ml-2">
                    / {dashboardData.tables} occupied
                  </span>
                </p>
              </div>

              <div className="border border-line bg-white rounded-xl p-5">
                <p className="font-body text-xs text-ink/40 uppercase tracking-wider">
                  Menu items
                </p>
                <p className="font-display text-3xl text-ink mt-3">
                  {dashboardData.menuItems}
                </p>
              </div>

              <div className="border border-line bg-white rounded-xl p-5">
                <p className="font-body text-xs text-ink/40 uppercase tracking-wider">
                  Customers
                </p>
                <p className="font-display text-3xl text-ink mt-3">
                  {dashboardData.customers}
                </p>
              </div>
            </div>

            <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-4">
              <Link
                to="/admin/kitchen"
                className="border border-line bg-charcoal text-paper rounded-xl p-6 block"
              >
                <p className="font-body text-sm text-paper/50">
                  Kitchen
                </p>

                <h3 className="font-display text-2xl mt-2">
                  Manage live orders
                </h3>

                <p className="font-body text-sm text-paper/50 mt-2">
                  View incoming orders and update their preparation status.
                </p>
              </Link>

              <Link
                to="/admin/waiter"
                className="border border-line bg-white rounded-xl p-6 block"
              >
                <p className="font-body text-sm text-ink/40">
                  Waiter
                </p>

                <h3 className="font-display text-2xl text-ink mt-2">
                  Serve ready orders
                </h3>

                <p className="font-body text-sm text-ink/50 mt-2">
                  See orders that are ready to be served.
                </p>
              </Link>
            </div>
          </section>
        )}

        {activeTab === 'menu' && (
          <MenuManagement
            restaurantId={user.restaurantId}
            token={token}
          />
        )}

        {activeTab === 'tables' && (
          <TableManagement
            restaurantId={user.restaurantId}
            token={token}
          />
        )}
      </main>
    </div>
  );
}

export default AdminDashboard;